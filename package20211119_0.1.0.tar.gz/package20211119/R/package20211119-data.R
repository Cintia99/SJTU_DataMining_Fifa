#' @docType data
#' @name d
#'
NULL

players_fifa22 <- read.csv("players_fifa22.csv")
library(devtools)
use_data(players_fifa22)
