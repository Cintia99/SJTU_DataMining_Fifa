players_fifa22 <- read.csv("players_fifa22.csv")
View(players_fifa22)
players_fifa22
